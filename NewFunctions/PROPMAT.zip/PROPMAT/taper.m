function [y] = taper(x,time,tpr,dt,t1,t2)
        
        % ********* Function Description *********
        %
        % TAPER  Taper a time series.
        %
        % TAPER(X,TIME,TPR,DT,T1,T2) takes time
        % series sampled at DT and tapers it with
        % a cosine taper TPR seconds long from
        % beginning point T1-TPR and with reverse
        % cosine taper from point T2 to point T2+
        % TPR. Points outside the range (T1-TPR,
        % T2+TPR) are zeroed. If T1/T2 is negative
        % then taper is not implemented at the
        % beginning/end. If X is an array of
        % seismograms, then the taper is applied
        % to each row of X.
        %
        %
        % ****************************************
        % *                                      *
        % *  Modified from Kate Rychert's        *
        % *  receiver function code - May 2008   *
        % *                                      *
        % *  Email: David_Abt@brown.edu          *
        % *                                      *
        % ****************************************
        
        nn      = length(x(1,:));
        nx      = length(x(:,1));
        taper   = ones(1,nn);
        it  	= (0:fix(tpr/dt))*dt/tpr;
        ct      = 0.5-0.5*cos(pi*it);
        T1      = fix(time(1)/dt);             % Absolute sample point of first time step
        it1     = fix(t1/dt+1)-T1;
        it2     = fix(t2/dt+1)-T1;
        
        % Emily, 6th May 2013: problem with start time of phase being <100s, so
        % taper subscripts are negative.
        % Temporary workaround, set taper length to be shorter.
        % N.B. Only one event so far has had this issue!
        
        if t1>0
            if it1>fix(tpr/dt)
                taper(it1-fix(tpr/dt):it1)	= ct;
                taper(1:it1-fix(tpr/dt))    = zeros(size(1:it1-fix(tpr/dt)));
            else
                taper(1:it1) = ct(fix(tpr/dt)-it1+2:end);
                taper(1) = 0;
                disp('Bizarre taper!')
                
            end
        end
        if t2>0
            if t2>time(end)-tpr
                t2  = time(end)-tpr;
                it2	= fix(t2/dt)-T1;
            end
            taper(it2:it2+fix(tpr/dt))	= fliplr(ct);
            taper(it2+fix(tpr/dt):nn)	= zeros(size(taper(it2+fix(tpr/dt):nn)));
        end
        
        y = zeros(nx,nn);
        for ix=1:nx
            y(ix,:) = x(ix,:).*taper;
        end
        
end