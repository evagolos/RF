#!/usr/bin/env python
#
def main():
	from matplotlib import pylab as plt
	from numpy import array
	
	fin=open('vmodel.txt')
	
	z,a,b,c=[],[],[],[]

	for line in fin.readlines():
		nfo=line.strip('\n').split()
		z.append(-float(nfo[0]))
		a.append(float(nfo[1]))
		b.append(float(nfo[2]))
		c.append(float(nfo[3]))	

	plt.subplot(1,3,1)
	plt.plot(a,z,'-b')
	plt.xlabel('Vs,Vp (km/s)')
	plt.ylabel('Depth (km)')
	plt.subplot(1,3,1)
	plt.plot(b,z,'-r')
	plt.subplot(1,3,2)
	plt.xlabel('Vp/Vs')
	plt.plot(array(a)/array(b),z,'-r')
	plt.subplot(1,3,3)
	plt.plot(c,z)
	plt.xlabel('Density')

	plot_ak135()

	plt.show()

def plot_ak135():
	from numpy import array
	from matplotlib import pylab as plt


	fin=open('ak135.txt','r')

	zs,vps,vss,dens=[],[],[],[]

	for line in fin.readlines():
		nfo=line.strip('\n').split()
		z=-float(nfo[0])
		vp=float(nfo[2])
		vs=float(nfo[3])
		den=float(nfo[1])
		if z<-350:
			continue		
		zs.append(z)
		vps.append(vp)
		vss.append(vs)
		dens.append(den)

	plt.subplot(1,3,1)
	plt.plot(vps,zs,'--k')
	plt.plot(vss,zs,'--r')
	plt.subplot(1,3,2)
	plt.plot(array(vps)/array(vss),zs,'--')


main()
