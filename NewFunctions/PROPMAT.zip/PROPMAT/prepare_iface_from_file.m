function [iface, rayparam, period] = prepare_iface_from_file(infile)
%File format
%nface rayparam period
%z dlnvp dlnvs dlnrho tranwid nlay

% 2    0.10 10.0 
% 10.0 0.10 0.10 0.10 100.0 1
% 20.0 0.05 

FID=fopen(infile,'r');

tmp=fgetl(FID);
tmp=sscanf(tmp,'%f');

nface=tmp(1);
rayparam=tmp(2);
period=tmp(3);

for ii = 1:nface;
	tmp=fgetl(FID);
	tmp=sscanf(tmp,'%f');
	iface(ii).z=tmp(1);
	iface(ii).dlnvp=tmp(2);
	iface(ii).dlnvs=tmp(3);
	iface(ii).dlnrho=tmp(4);
	iface(ii).tranwid=tmp(5);
	iface(ii).nlay=tmp(6);
end

fclose(FID);
end
