function [ztop,zbot,vp,vs,rho] = construct_plane_layered_model(iface)

vpref = 7.28;   %6.15;
vsref = 4.7/1.1;  %Note this is slower than ak135 (needed to give realistic values within the lithosphere)
rhoref= 2.80;
zref=0.0;

%Calc number of layers
N=sum([iface.nlay]);

ztop=zeros(N,1);
zbot=zeros(N,1);
vp=zeros(N,1);
vs=zeros(N,1);
rho=zeros(N,1);

disp(zbot)

ilay=0;
for ii = 1:length(iface);
	nlay=iface(ii).nlay;
	if nlay == 1;
		ilay=ilay+1;
		ztop(ilay)=zref;
		zref=iface(ii).z;
		zbot(ilay)=zref;
		vp(ilay)=vpref;
		vs(ilay)=vsref;
		rho(ilay)=rhoref;
		vpref=vpref*(1.0+iface(ii).dlnvp);
		vsref=vsref*(1.0+iface(ii).dlnvs);
		rhoref=rhoref*(1.0+iface(ii).dlnrho);
	else;
	
		vp1=vpref;
		vs1=vsref;
		rho1=rhoref;
		vpref=vpref*(1.0+iface(ii).dlnvp);
		vsref=vsref*(1.0+iface(ii).dlnvs);
		rhoref=rhoref*(1.0+iface(ii).dlnrho);
		vp2=vpref;
		vs2=vsref;
		rho2=rhoref;

		z1=iface(ii).z-iface(ii).tranwid/2.0;
		z2=iface(ii).z+iface(ii).tranwid/2.0;
		
		%Fill in from previous
		ilay=ilay+1;
		ztop(ilay)=zref;
		zbot(ilay)=z1;
		vp(ilay)=vp1;
		vs(ilay)=vs1;
		rho(ilay)=rho1;

		vptmp=linspace(vp1,vp2,nlay+1);
		vstmp=linspace(vs1,vs2,nlay+1);		
		rhotmp=linspace(rho1,rho2,nlay+1);
		ztmp=linspace(z1,z2,nlay+1);

		for jj = 1:nlay;
			ilay=ilay+1;
			vp(ilay)=(vptmp(jj)+vptmp(jj+1))/2.0;
			vs(ilay)=(vstmp(jj)+vstmp(jj+1))/2.0;
			rho(ilay)=(rhotmp(jj)+rhotmp(jj+1))/2.0;
			ztop(ilay)=ztmp(jj);
			zbot(ilay)=ztmp(jj+1);
		end
		
		%Update zref
		zref=zbot(ilay);

	end
end
