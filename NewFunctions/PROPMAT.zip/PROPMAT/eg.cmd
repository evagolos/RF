#!/bin/csh
set xdir=/Volumes/Seagate3/Nanatolian/NewFunctions/PROPMAT
$xdir/synth <<!
eg.mod
eg_synth.out0
eg_synth.out1
eg_synth.out2
eg_synth.in
24.4
!
echo "Done propagation, now convolving source"
$xdir/sourc1 <<!
eg.rtz
eg_synth.out1
eg_synth.out2
0 1 0
13.0
0.0
2
!
echo "Done source convolution, cleaning up..."
rm imag_part.out
