function [ RF , Time ] = getrf( Rcomp , Zcomp , dt ,a ,b , rp)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

sigwin = 5;
noiwin = 25;
sigs = smooth(abs(hilbert(Rcomp)),sigwin/dt);
nois = smooth(abs(hilbert(Rcomp)),noiwin/dt);
s2n = sigs(noiwin/dt+sigwin/dt/2:end-sigwin/dt/2)./nois(noiwin/dt/2:end-noiwin/dt/2-sigwin/dt);
indarr = find(s2n==max(s2n))+noiwin/dt;
if length(indarr)>1 
    indarr = indarr(1);
end

qa  = sqrt((a^-2)-(rp^2));
qb  = sqrt((b^-2)-(rp^2));
A   = rp*(b^2)/a;
B   = ((b^2)*(rp^2)-0.5)/(a*qa);
C   = (0.5-(b^2)*(rp^2))/(b*qb);
D   = rp*b;
Pcomp = A*Rcomp-B*Zcomp;
SVcomp = C*Rcomp-D*Zcomp;

lowT = 4;
highT = 100;
nyq=0.5/dt;
[b1,b2] = butter(2,[1/highT/nyq,1/lowT/nyq]);
Par_rf = filtfilt(b1,b2,SVcomp');
Dau_rf = filtfilt(b1,b2,Pcomp');
winlen = 50;
poverlap = 0.9;
nwins = 7;
win_s = indarr-winlen/dt/2-round((1-poverlap)*winlen*(nwins-1)/dt);
win_e = indarr+winlen/dt/2;
n2=2^nextpow2(win_e-win_s);
if win_s<=0
    Dau_rf = [zeros(1,abs(win_s)+1),Dau_rf];
    Par_rf = [zeros(1,abs(win_s)+1),Par_rf];
    win_s = 1;
end
tpr= 0.5;
Taper(1) = win_s*dt;
Taper(2) = win_e*dt;
time_rf = 0:dt:(length(Par_rf)-1)*dt;
Par_rf = taper(Par_rf,time_rf,tpr,dt,Taper(1),Taper(2));
Dau_rf = taper(Dau_rf,time_rf,tpr,dt,Taper(1),Taper(2));
Dau_rf = [Dau_rf(win_s:win_e)];
Par_rf = [Par_rf(win_s:win_e)];
%[Time, RF] = ETMTM(Par_rf,Dau_rf,4,7,'data',dt,winlen,poverlap); 
[RF,Time] = IDRF(Par_rf,Dau_rf,dt,5,5,1,0.01,0.005,50);
Time = fliplr(Time);

RF = flipud(RF);

end
