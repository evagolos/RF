function[RF, RF_Time] = IDRF(P,D,dt,t_for,t_trun,gauss_t,accept_mis,tag)
% Iterative Deconvolution and Receiver-Function Estimation in time domain

t_max = t_for;

misfit = 1;
misfit_old = 9999;
misfit_ref = sqrt(sum(D.^2));

RF = zeros(length(P)*2-1,1);
RF_tmp = zeros(length(P)*2-1,1);

D_cur = D;

itmax = 20;
%plot(D_cur)
%hold on
%for i=1:it_num

itnum = 0;

[~,t_corr] = xcorr(D_cur,P);
RF_Time = t_corr*dt;

while misfit_old-misfit>accept_mis && itnum <= itmax
    [amp_corr,~] = xcorr(D_cur,P);
    auto_corr = xcorr(P);
    [~,ind] = max(abs(amp_corr));
    amp_rf = amp_corr(ind)/auto_corr((length(t_corr)+1)/2);
    
    if RF_Time(ind) > -9.5 && (amp_rf>0 || abs(amp_rf)<0.02)
        RF_tmp(ind) = RF_tmp(ind)+amp_rf;
    else
        RF_tmp(ind) = RF_tmp(ind)+amp_rf;
        RF(ind) = RF(ind)+amp_rf;
    end
    
    D_sub = conv(P,RF_tmp,'same');
    D_cur = D - D_sub;
    %plot(D_cur)
    misfit_old = misfit;
    misfit = sqrt(sum(D_cur.^2))/misfit_ref;
    itnum = itnum+1;
end

RF = RF_tmp;


RF(RF_Time>t_trun)=0;
RF = RF(RF_Time<t_max);
RF_Time = RF_Time(RF_Time<t_max);

if gauss_t~=0
    %gauss_sig = gauss_t/dt;
    % gauss_len = length(RF);
    % Gauss_win = gausswin(gauss_len,gauss_sig*4);
    wl_T = 1/centfrq('mexh');
    times_T = gauss_t/wl_T;
    dt_wl = dt/times_T;
    bd_wl = round(50/dt_wl)*dt_wl;
    N_wl = 2*round(50/dt_wl)+1;
    WL_win = mexihat(-bd_wl/2,bd_wl/2,N_wl);
    
    n_fft_gau = 2^nextpow2(length(WL_win));
    pad = ceil((n_fft_gau-length(WL_win))/2);
    gau_tmp = [zeros(pad-1,1);WL_win';zeros(pad,1)];
    gau_fft = fft(hilbert(gau_tmp));
    gau_level = gau_fft(1);
    gau_fft = fftshift(gau_fft);
    gau_F_fft = 1/dt*((-n_fft_gau/2):(n_fft_gau/2-1))/n_fft_gau;
    %gau_fft = gau_fft./((1i*2*pi*gau_F_fft').^(1));
    gau_fft = -gau_fft.*((1i*2*pi*gau_F_fft').^(3/2)).*1i;
    
    gau_fft = ifftshift(gau_fft);
    gau_fft(1) = gau_level;
    %RF_fft(1) = 0;
    gau_shift = ifft(gau_fft);
    if length(gau_shift) ~= length(WL_win)
        gau_shift(end-pad+1:end) = [];
        if pad>1
            gau_shift(1:pad-1) = [];
        end
        
        %gau_shift(length(Gauss_win)+1:end) = [];
    end
    gau_shift = real(gau_shift');
%     gau_shift = interp1(x,gau_shift,x_dt);
%     Gauss_win = interp1(x,Gauss_win,x_dt);

%     gauss_sig = gauss_t/dt;
%     x = linspace(-gauss_sig*4,gauss_sig*4,gauss_sig*8);
%     Gauss_win = exp(-x.^2/(2*gauss_sig^2));
    
    %RF = conv(RF,Gauss_win,'same');
    
    if strcmp(tag,'ori')
        RF = conv(RF,WL_win,'same');
    elseif strcmp(tag,'shift')
        RF = conv(RF,gau_shift,'same');
    end
end


%plot(dt*t_corr(t_corr<0 & dt*t_corr>-40),RF_a(t_corr<0 & dt*t_corr>-40))

%pause



end