#!/usr/bin/env python
#
#
def write_timeseries_to_sac(data,channel,outfile,tstart,sampling_rate):
	import obspy as obs
	
	#Write blank sac file
	tr = obs.Trace()
	tr.stats.station='YK3SY'
	tr.stats.sampling_rate=sampling_rate
	tr.stats.channel=channel
	tr.stats.starttime=obs.UTCDateTime(1900, 1, 1, 1, 1) + tstart
	tr.write(outfile, format='SAC') 
	
	st = obs.read(outfile)
	tr=st[0]
	
	tr.data=data

	if channel == 'BHE':
		tr.stats.sac.cmpaz=90.
	elif channel == 'BHN':
		tr.stats.sac.cmpaz= 0.
	
	tr.write(outfile, format='SAC') 
	
	#print(tr.stats)
	
	return
