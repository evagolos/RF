#!/usr/bin/env python
#
def write_to_sac(infile,dt):
	#from matplotlib import pylab as plt
	from numpy import zeros,array,arange
	from TOOLS import write_timeseries_to_sac

	CH1,CH2,CH3=[],[],[]

	fin=open(infile,'r')
	
	tmp=zeros(3)
	
	for it in range(5):
		line=fin.readline()

	for line in fin.readlines():
		
		nfo=line.strip('\n').split()
		
		for i in range(3):
			tmp[i]=float(nfo[i])
			
		CH1.append(tmp[0])
		CH2.append(tmp[1])
		CH3.append(tmp[2])
		
	CH1=array(CH1)
	CH2=array(CH2)
	CH3=array(CH3)
	
	#Prefilter
	#print 'Prefiltering'
	
	#calculate delay time
	
	imax=abs(CH1).argmax()
	time=arange(len(CH1))*dt
	tmax=time[imax]  # in sec
	
	tS=1225.0 # s for a distance of 70 degrees (rp roughly 0.1 s/km)
	tstart=tS-tmax  # tstart is after event origin time
	
	sampRate=1.0/dt

	write_timeseries_to_sac(CH1,'BHN','BHN.SAC',tstart,sampRate)
	write_timeseries_to_sac(CH2,'BHE','BHE.SAC',tstart,sampRate)
	write_timeseries_to_sac(CH3,'BHZ','BHZ.SAC',tstart,sampRate)

	return
	
