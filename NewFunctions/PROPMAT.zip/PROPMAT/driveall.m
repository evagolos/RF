% infile='test.txt';
% 
% [iface,RayParam,Period] = prepare_iface_from_file(infile);
% [ztop,zbot,vp,vs,rh]    = construct_plane_layered_model(iface);
RayParam = [0.0840,0.0887,0.0933,0.0980];
RayParam = sind(23)/4.05;
%RayParam = 0.1054;
Period = 8.4;
recordid='caseBOSAonlyMoho';
recordid='caseBOSA';
recordid='caseNZ';
recordid='casesyntest';
switch recordid
    case 'case1'
        vs = [4.28 ; 4.7; 4.38; 4.7];
        vp = [7.28 ; 8.00; 7.46; 8.00];
        rho = [2.8;3.36;3.3;3.36];
        zbot = [35 ; 95 ; 105 ; 200];
        ztop = [0 ; 35 ; 95 ; 105];
    case 'case2'
        vs = [4.28 ; 4.7; (linspace(4.38,4.7,41))'; 4.7];
        vp = [7.28 ; 8.00; (linspace(7.46,8.00,41))'; 8.00];
        rho = [2.8;3.36;(linspace(3.3,3.36,41))';3.36];
        zbot = [35 ; 95 ; (linspace(105,125,41))' ; 200];
        ztop = [0 ; 35 ; 95 ; (linspace(105,125,41))'];
    case 'case3'
        vs = [4.28 ; 4.7; 4.65; 4.7];
        vp = [7.28 ; 8.00; 7.90; 8.00];
        rho = [2.8;3.36;3.3;3.36];
        zbot = [35 ; 95 ; 105 ; 200];
        ztop = [0 ; 35 ; 95 ; 105];
    case 'case4'
        vs = [4.28 ; 4.7; (linspace(4.65,4.7,41))'; 4.7];
        vp = [7.28 ; 8.00; (linspace(7.90,8.00,41))'; 8.00];
        rho = [2.8;3.36;(linspace(3.3,3.36,41))';3.36];
        zbot = [35 ; 95 ; (linspace(105,125,41))' ; 200];
        ztop = [0 ; 35 ; 95 ; (linspace(105,125,41))'];
    case 'case5'
        vs = [4.28 ; 4.7; 4.38; 4.38; 4.7];
        vp = [7.28 ; 8.00; 7.46; 7.46; 8.00];
        rho = [2.8;3.36;3.3;3.3 ; 3.36];
        zbot = [35 ; 60; 85 ; 105 ; 200];
        ztop = [0 ; 35 ; 60; 85 ; 105];
    case 'case6'
        vs = [4.28 ; 4.7; 4.38; (linspace(4.38,4.7,41))'; 4.7];
        vp = [7.28 ; 8.00; 7.46; (linspace(7.46,8.00,41))'; 8.00];
        rho = [2.8;3.36;3.3;(linspace(3.3,3.36,41))';3.36];
        zbot = [35 ; 60; 85 ; (linspace(105,125,41))' ; 200];
        ztop = [0 ; 35 ; 60; 85 ; (linspace(105,125,41))']; 
    case 'caseBOSA'
        vs = [4.1 ; 4.7 ; (linspace(4.45,4.7,33))'; 4.7];
        vp = vs.*[1.7;1.8*ones(length(vs)-1,1)];
        rho = [2.8 ; 3.36 ; (linspace(3.3,3.36,33))';3.36];
        zbot = [31 ; 72 ; (linspace(74,90,33))' ; 200];
        ztop = [0 ; 31 ; 72 ; (linspace(74,90,33))'];
    case 'caseBOSAonlyMoho'
        vs = [4.1 ; 4.7];
        vp = [1.7;1.8].*vs;
        rho = [2.8 ; 3.36 ];
        zbot = [31 ; 200];
        ztop = [0 ; 31 ];
    case 'caseNZ'
        vp = [6.0;7.0;8.0;7.2];
        vs = vp./[1.7;1.7;1.8;1.75];
        rho = [2.8; 2.8; 3.3 ; 3.3 ];
        zbot = [33; 44; 96 ; 200];
        ztop = [0 ; 33; 44; 96 ];
        
    case 'casesyntest'
        vs = [3.2 ; 4.25; 4.05];    %original lithosphere vs = 4.5
        vp = [5.6 ; 4.25*1.8; 7.2];     %original lithosphere vp = 8.1
        rho = [2.8;3.3;3.3];
        zbot = [25 ; 100 ;400];
        ztop = [0 ; 25 ; 100];
end
depth=0:0.1:200;
rfs = zeros(length(RayParam),length(depth));
for i=1:length(RayParam)
    write_propmat_syn(ztop,zbot,vp,vs,rho,RayParam(i),Period,[recordid,'.mat']);
    load([recordid,'.mat'])
    [RF , Time] = getrf(R,Z,dt,vp(1),vs(1),RayParam(i));
    [Depth,indts,indte] = getdepth(Time,zbot,vp,vs,RayParam(i));
    rfs(i,:) = interp1(Depth,RF(indts:indte),depth);
end

rfs(isnan(rfs))=0;
rfs = -rfs;
rfp = mean(rfs,1);

rfru = rfp;
depru = depth;

save(['synresults',recordid,'.mat'],'rfru','depru');

load('../NZreview.mat');
%RFcal(cp_depths<55 | cp_depths>140) = 0;
RFcal = -RFcal;
%STDcal(cp_depths<55 | cp_depths>140) = 0;
moho = max(RFcal(cp_depths>20 & cp_depths<60));
rfp = moho/max(rfp(depth>20 & depth<60))*rfp;

figure
set(gcf,'position',[680 300 470 790])
plot([0 0],[0 200],'k--'); hold on; set(gca,'ydir','reverse')
set(gca,'fontsize',13)
plot(RFcal,cp_depths,'k','linewidth',2);


inds=find(RFcal>0);
if ~isempty(inds)
    dinds=[find(diff(inds)>1) length(inds)]; sind=1;
    for k=1:length(dinds); pinds=inds(sind):inds(dinds(k));
        if RFcal(pinds(1))>1e-3; MPRF=[0 RFcal(pinds)];
            TRF2=[0 cp_depths(pinds)];
        else MPRF=RFcal(pinds); TRF2=cp_depths(pinds);
        end
        if RFcal(pinds(end))>1e-3; MPRF=[MPRF 0]; TRF2=[TRF2 TRF2(end)]; end
        h=fill(MPRF, TRF2,'r','linestyle','none');
        set(h,'facealpha',0.5);sind=1+dinds(k);
    end
end

inds=find(RFcal<0);
if ~isempty(inds)
    dinds=[find(diff(inds)>1) length(inds)]; sind=1;
    for k=1:length(dinds); pinds=inds(sind):inds(dinds(k));
        if RFcal(pinds(1))<-1e-3; PPRF=[0 RFcal(pinds)];
            TRF2=[0 cp_depths(pinds)];
        else PPRF=RFcal(pinds); TRF2=cp_depths(pinds);
        end
        if RFcal(pinds(end))<-1e-3; PPRF=[PPRF 0]; TRF2=[TRF2 TRF2(end)]; end
        h=fill(PPRF, TRF2,'b','linestyle','none');
        set(h,'facealpha',0.5); sind=1+dinds(k);
    end
end

xlim([min(RFcal)-0.005,max(RFcal)+0.005]);
ylabel('Depth (km)','fontsize',15); xlabel('RF Amplitude','fontsize',15); ylim([0 200])
title(recordid,'fontsize',18)


figure
set(gcf,'position',[680 300 470 790])
plot([0 0],[0 200],'k--'); hold on; set(gca,'ydir','reverse')
set(gca,'fontsize',13)
plot(rfp,depth,'k','linewidth',2);


inds=find(rfp>0);
if ~isempty(inds)
    dinds=[find(diff(inds)>1) length(inds)]; sind=1;
    for k=1:length(dinds); pinds=inds(sind):inds(dinds(k));
        if rfp(pinds(1))>1e-3; MPRF=[0 rfp(pinds)];
            TRF2=[0 depth(pinds)];
        else MPRF=rfp(pinds); TRF2=depth(pinds);
        end
        if rfp(pinds(end))>1e-3; MPRF=[MPRF 0]; TRF2=[TRF2 TRF2(end)]; end
        h=fill(MPRF, TRF2,'r','linestyle','none');
        set(h,'facealpha',0.5);sind=1+dinds(k);
    end
end

inds=find(rfp<0);
if ~isempty(inds)
    dinds=[find(diff(inds)>1) length(inds)]; sind=1;
    for k=1:length(dinds); pinds=inds(sind):inds(dinds(k));
        if rfp(pinds(1))<-1e-3; PPRF=[0 rfp(pinds)];
            TRF2=[0 depth(pinds)];
        else PPRF=rfp(pinds); TRF2=depth(pinds);
        end
        if rfp(pinds(end))<-1e-3; PPRF=[PPRF 0]; TRF2=[TRF2 TRF2(end)]; end
        h=fill(PPRF, TRF2,'b','linestyle','none');
        set(h,'facealpha',0.5); sind=1+dinds(k);
    end
end

xlim([min(rfp)-0.005,max(rfp)+0.005]);
ylabel('Depth (km)','fontsize',15); xlabel('RF Amplitude','fontsize',15); ylim([0 200])
title(recordid,'fontsize',18)
%print(recordid,'-dpng','-r300')

figure
set(gcf,'position',[680 300 470 790])
vsplot = zeros(2001,1);
for i=1:length(zbot)
    vsplot(depth<=zbot(i) & depth>=ztop(i))=vs(i);
end
plot(vsplot,depth,'k','linewidth',2);
set(gca,'fontsize',13)
hold on; set(gca,'ydir','reverse')
xlim([min(vs)-0.1,max(vs)+0.1])

ylabel('Depth (km)','fontsize',15); xlabel('Vs (km/s)','fontsize',15); ylim([0 200])
title(recordid,'fontsize',18)
%print([recordid,'_Vs'],'-dpng','-r300')



figure
subplot(1,2,1)
set(gcf,'position',[150 300 470 790])
plot([0 0],[0 200],'k--'); hold on; set(gca,'ydir','reverse')
set(gca,'fontsize',13)
plot(rfp,depth,'k','linewidth',2);
depth=0:0.1:200;
%rfp = interp1(Depth,RF(indts:indte),depth);
inds=find(rfp>0);
if ~isempty(inds)
    dinds=[find(diff(inds)>1) length(inds)]; sind=1;
    for k=1:length(dinds); pinds=inds(sind):inds(dinds(k));
        if rfp(pinds(1))>1e-3; MPRF=[0 rfp(pinds)];
            TRF2=[0 depth(pinds)];
        else MPRF=rfp(pinds); TRF2=depth(pinds);
        end
        if rfp(pinds(end))>1e-3; MPRF=[MPRF 0]; TRF2=[TRF2 TRF2(end)]; end
        h=fill(MPRF, TRF2,'r','linestyle','none');
        set(h,'facealpha',0.5);sind=1+dinds(k);
    end
end

inds=find(rfp<0);
if ~isempty(inds)
    dinds=[find(diff(inds)>1) length(inds)]; sind=1;
    for k=1:length(dinds); pinds=inds(sind):inds(dinds(k));
        if rfp(pinds(1))<-1e-3; PPRF=[0 rfp(pinds)];
            TRF2=[0 depth(pinds)];
        else PPRF=rfp(pinds); TRF2=depth(pinds);
        end
        if rfp(pinds(end))<-1e-3; PPRF=[PPRF 0]; TRF2=[TRF2 TRF2(end)]; end
        h=fill(PPRF, TRF2,'b','linestyle','none');
        set(h,'facealpha',0.5); sind=1+dinds(k);
    end
end
xlim([min(rfp)-0.005,max(rfp)+0.005]);
ylabel('Depth (km)','fontsize',15); xlabel('RF Amplitude','fontsize',15); ylim([0 200])


subplot(1,2,2)
set(gcf,'position',[800 300 470 790])
vsplot = zeros(2001,1);
for i=1:length(zbot)
    vsplot(depth<=zbot(i) & depth>=ztop(i))=vs(i);
end
plot(vsplot,depth,'k','linewidth',2);
set(gca,'fontsize',13)
hold on; set(gca,'ydir','reverse')
xlim([4,4.8])

ylabel('Depth (km)','fontsize',15); xlabel('Vs (km/s)','fontsize',15); ylim([0 200])

text(3.95,-10,recordid,'fontsize',18);

save(['synresults',recordid,'vs.mat'],'vsplot','depth');

%print([recordid,'_Combine'],'-dpng','-r300')




