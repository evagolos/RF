#!/usr/bin/env python
#
#
from TOOLS import write_to_sac
write_to_sac("out.tr",0.100000)
