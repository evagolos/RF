function [ Depth, indts, indte] = getdepth(Phase, Time,zbot,vp,vs,rp )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
ts = zeros(length(vp)+1,1);
tp = zeros(length(vp)+1,1);
dep = zeros(length(vp)+1,1);
xs = zeros(length(vp)+1,1);
xp = zeros(length(vp)+1,1);
Zint = [0;zbot];
for i=1:length(vp)
    ts(i+1) = ts(i)+(Zint(i+1)-Zint(i))/(vs(i)*sqrt(1-(vs(i)*rp)^2));
    dep(i+1) = zbot(i);
    xs(i+1) = xs(i)+(Zint(i+1)-Zint(i))*vs(i)*rp/sqrt(1-(vs(i)*rp)^2);
    tp(i+1) = tp(i)+(Zint(i+1)-Zint(i))/(vp(i)*sqrt(1-(vp(i)*rp)^2));
    xp(i+1) = xp(i)+(Zint(i+1)-Zint(i))*vp(i)*rp/sqrt(1-(vp(i)*rp)^2);
end


if(strcmp(Phase,"Sp"))
    difft = tp-ts-rp*(xp-xs);
    dep(imag(difft)~=0) = [];
    difft(imag(difft)~=0) = [];
    indts = find(Time<=difft(1),1);
    indte = find(Time<difft(end),1)-1;
    Depth = interp1(difft,dep,(Time(indts:indte))');
end
if(strcmp(Phase,"Ps"))
    difft = ts-tp+rp*(xp-xs);
    dep(imag(difft)~=0) = [];
    difft(imag(difft)~=0) = [];
    indte = find(Time<=difft(1),1);
    indts = find(Time<difft(end),1);
    Depth = interp1(difft,dep,(Time(indts:indte))');
end
%Depth = interp1(difft,dep,(Time(indts:indte))');


end

